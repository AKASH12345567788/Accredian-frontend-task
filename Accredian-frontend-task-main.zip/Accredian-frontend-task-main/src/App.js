
import './App.css';
import LoginPage from './components/Login/Login';


function App() {
  return (
    <div>
      <LoginPage/>
      
    </div>
  );
}

export default App;
